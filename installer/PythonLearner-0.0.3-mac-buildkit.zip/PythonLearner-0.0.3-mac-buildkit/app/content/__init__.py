"""Kurs-inhalt: kapitel-registry und validate-helfer."""
from . import (
    ch00_start, ch01_variables, ch02_control, ch03_lists, ch04_strings,
    ch05_functions, ch06_dictionaries, ch07_sets, ch08_classes,
    ch09_modules, ch10_exceptions_intro, ch11_string_processing,
    ch12_four_programs, ch13_oop_deep_dive, ch14_oop_inheritance,
    ch15_exceptions_deep, ch16_generators, ch17_hof_lambdas,
    ch18_file_processing, ch19_labs,
)

CHAPTERS = [
    ch00_start.CHAPTER,
    ch01_variables.CHAPTER,
    ch02_control.CHAPTER,
    ch03_lists.CHAPTER,
    ch04_strings.CHAPTER,
    ch05_functions.CHAPTER,
    ch06_dictionaries.CHAPTER,
    ch07_sets.CHAPTER,
    ch08_classes.CHAPTER,
    ch09_modules.CHAPTER,
    ch10_exceptions_intro.CHAPTER,
    ch11_string_processing.CHAPTER,
    ch12_four_programs.CHAPTER,
    ch13_oop_deep_dive.CHAPTER,
    ch14_oop_inheritance.CHAPTER,
    ch15_exceptions_deep.CHAPTER,
    ch16_generators.CHAPTER,
    ch17_hof_lambdas.CHAPTER,
    ch18_file_processing.CHAPTER,
    ch19_labs.CHAPTER,
]


def find_item(item_id):
    for ch in CHAPTERS:
        for item in ch["items"]:
            if item["id"] == item_id:
                return item
    return None


def iter_tasks():
    for ch in CHAPTERS:
        for item in ch["items"]:
            if item["type"] == "task":
                yield ch, item


def validate_structure():
    """Checks ohne ausführen: unique ids, pflichtfelder."""
    errors = []
    seen = set()
    for ch in CHAPTERS:
        if ch["id"] in seen:
            errors.append(f"duplicate chapter id {ch['id']}")
        seen.add(ch["id"])
        for item in ch["items"]:
            if item["id"] in seen:
                errors.append(f"duplicate item id {item['id']}")
            seen.add(item["id"])
            t = item["type"]
            if t == "task":
                if not item.get("tests"):
                    errors.append(f"{item['id']}: no tests")
                if not item.get("hints"):
                    errors.append(f"{item['id']}: no hints")
                if not item.get("solution"):
                    errors.append(f"{item['id']}: no solution")
                if len(item.get("explanation") or "") < 150:
                    errors.append(f"{item['id']}: explanation missing or < 150 chars")
                ex = item.get("example")
                if ex is not None:
                    if not isinstance(ex, str) or "```python" not in ex:
                        errors.append(f"{item['id']}: example must be a string with a python fence")
                # beispiel pflicht: ch01-05 komplett, sonst nur bei bossen
                ch_num = int(item["id"][2:4])
                if (1 <= ch_num <= 5 or (item.get("boss") and ch_num >= 6)) and ex is None:
                    errors.append(f"{item['id']}: missing example")
            elif t == "quiz":
                opts = item.get("options", [])
                if not (2 <= len(opts) <= 6):
                    errors.append(f"{item['id']}: bad options")
                if not (0 <= item.get("answer", -1) < len(opts)):
                    errors.append(f"{item['id']}: bad answer index")
                if not item.get("explanation"):
                    errors.append(f"{item['id']}: no explanation")
            elif t == "lesson":
                if not item.get("body"):
                    errors.append(f"{item['id']}: empty body")
            else:
                errors.append(f"{item['id']}: unknown type {t}")
    return errors
